-- ==========================================
-- THE UNLOX ACADEMY
-- WEEK 3 SQL FOUNDATIONS ASSESSMENT
-- Name: Sai Pavan
-- ==========================================

USE flipcart;

-- SECTION A: THEORY (A1-A8)

-- A1. In MySQL, what is the relationship between a schema and a database?
-- a) Schema is a group of databases
-- b) Database is a group of schemas
-- c) Schema and database are the same thing in MySQL
-- d) Schema is a virtual view of a database
-- Answer: c

-- A2. Which SQL command family does TRUNCATE TABLE belong to?
-- a) DML (Data Manipulation Language)
-- b) DDL (Data Definition Language)
-- c) DQL (Data Query Language)
-- d) DCL (Data Control Language)
-- Answer: b

-- A3. You are designing a table to store product prices for an e-commerce site (e.g. 299.50, 79,999.00). Which data type is the most appropriate?
-- a) FLOAT
-- b) DECIMAL
-- c) VARCHAR
-- d) INT
-- Answer: b

-- A4. You try to INSERT a row into an orders table with a customer_id that doesn't exist in the customers table. There is a foreign key constraint. What happens?
-- a) The row is inserted with NULL for customer_id
-- b) The row is inserted and a warning is logged
-- c) The INSERT fails with a foreign key constraint error
-- d) The row is inserted but marked as invalid
-- Answer: c

-- A5. Which of the following statements is TRUE about WHERE vs HAVING?
-- a) WHERE and HAVING can be used interchangeably
-- b) WHERE filters individual rows before aggregation; HAVING filters groups after aggregation
-- c) HAVING is used for row-level filtering; WHERE is used for group filtering
-- d) HAVING is faster than WHERE
-- Answer: b

-- A6. What is the result of the query: SELECT * FROM products WHERE avg_rating = NULL;
-- a) Returns all rows where avg_rating is NULL
-- b) Returns all rows where avg_rating is NOT NULL
-- c) Returns 0 rows (no rows match)
-- d) Throws a syntax error
-- Answer: c

-- A7. What is the difference between COUNT(*) and COUNT(column_name)?
-- a) They are identical
-- b) COUNT(*) counts all rows; COUNT(column_name) counts only non-NULL values in that column
-- c) COUNT(*) is faster but less accurate
-- d) COUNT(column_name) returns only distinct values
-- Answer: b

-- A8. Which command permanently removes an entire table (both structure and data), and CANNOT be undone by ROLLBACK?
-- a) DELETE FROM table_name
-- b) TRUNCATE TABLE table_name
-- c) DROP TABLE table_name
-- d) REMOVE TABLE table_name
-- Answer: c

-- SECTION B: OUTPUT PREDICTION (B1-B8)

-- B1. What does this query return?
-- SELECT COUNT(*) FROM products WHERE category = 'Electronics';
-- Answer: Returns the single numeric value 8 (row count of Electronics products).

-- B2. How many rows does this query return?
-- SELECT FROM products WHERE price BETWEEN 1000 AND 3000;
-- Answer: Returns 0 rows (syntax error due to missing column list after SELECT).

-- B3. What is the output of this query?
-- SELECT product_name FROM products WHERE category = 'Books' AND price < 400 ORDER BY price DESC LIMIT 1;
-- Answer: Returns 1 row: 'Rich Dad Poor Dad'.

-- B4. How many rows does this query return?
-- SELECT * FROM products WHERE avg_rating IS NULL;
-- Answer: Returns 3 rows (products with NULL average ratings).

-- B5. What single value does this query return?
-- SELECT MAX(price) FROM products WHERE category = 'Books';
-- Answer: Returns the single value 299.00.

-- B6. What does this query return?
-- SELECT category, COUNT(*) FROM products WHERE is_active = TRUE GROUP BY category HAVING COUNT(*) > 4;
-- Answer: Returns 2 rows showing categories with > 4 active products: 'Electronics' (7) and 'Apparel' (6).

-- B7. What does the output look like?
-- SELECT product_name, CASE WHEN price < 500 THEN 'Budget' WHEN price < 5000 THEN 'Mid' ELSE 'Premium' END AS tier FROM products WHERE category = 'Beauty';
-- Answer: Returns 4 rows listing product names in the Beauty category along with their computed tier ('Mid' / 'Budget' / 'Premium').

-- B8. What does this query return?
-- SELECT product_name, COALESCE (avg_rating, 0) AS rating FROM products WHERE stock_quantity = 0;
-- Answer: Returns 2 rows listing product names for out-of-stock items along with their ratings (or 0 if NULL).

-- SECTION C: APPLIED SQL (C1-C24)

-- C1. Display all products with all columns
SELECT *
FROM products;

-- C2. Product name and price of all Books
SELECT product_name, price
FROM products
WHERE category = 'Books';

-- C3. Products priced above ₹10,000 sorted highest to lowest
SELECT *
FROM products
WHERE price > 10000
ORDER BY price DESC;

-- C4. Top 5 most expensive products in Electronics
SELECT product_name, price
FROM products
WHERE category = 'Electronics'
ORDER BY price DESC
LIMIT 5;

-- C5. Products in Electronics or Apparel category
SELECT *
FROM products
WHERE category IN ('Electronics', 'Apparel');

-- C6. Products with price between ₹500 and ₹2,000 (inclusive)
SELECT *
FROM products
WHERE price BETWEEN 500 AND 2000;

-- C7. Products whose product_name contains 'Watch'
SELECT *
FROM products
WHERE product_name LIKE '%Watch%';

-- C8. Products whose brand starts with 'S'
SELECT *
FROM products
WHERE brand LIKE 'S%';

-- C9. Unique categories in products table
SELECT DISTINCT category
FROM products;

-- C10. Total number of products in catalogue
SELECT COUNT(*) AS total_products
FROM products;

-- C11. Average price of all Books
SELECT AVG(price) AS avg_book_price
FROM products
WHERE category = 'Books';

-- C12. Maximum and minimum price across all products
SELECT 
    MAX(price) AS max_price,
    MIN(price) AS min_price
FROM products;

-- C13. Product count per category
SELECT category, COUNT(*) AS product_count
FROM products
GROUP BY category;

-- C14. Total stock quantity for each category
SELECT category, SUM(stock_quantity) AS total_stock
FROM products
GROUP BY category;

-- C15. Average price per category sorted highest to lowest
SELECT category, AVG(price) AS avg_price
FROM products
GROUP BY category
ORDER BY avg_price DESC;

-- C16. Product count and average price for brands with > 1 product
SELECT brand, COUNT(*) AS product_count, AVG(price) AS avg_price
FROM products
GROUP BY brand
HAVING COUNT(*) > 1;

-- C17. Categories with more than 4 active products
SELECT category, COUNT(*) AS active_product_count
FROM products
WHERE is_active = TRUE
GROUP BY category
HAVING COUNT(*) > 4;

-- C18. 3 most expensive products in the catalogue
SELECT *
FROM products
ORDER BY price DESC
LIMIT 3;

-- C19. Categories where average price is above ₹2,000
SELECT category, AVG(price) AS avg_price
FROM products
GROUP BY category
HAVING AVG(price) > 2000;

-- C20. Products where avg_rating is missing
SELECT *
FROM products
WHERE avg_rating IS NULL;

-- C21. Display product_name and rating ('New Launch' if NULL)
SELECT 
    product_name,
    COALESCE(CAST(avg_rating AS CHAR), 'New Launch') AS rating
FROM products;

-- C22. Classify products into price_tier
SELECT 
    product_name,
    price,
    CASE 
        WHEN price < 1000 THEN 'Budget'
        WHEN price < 10000 THEN 'Mid'
        ELSE 'Premium'
    END AS price_tier
FROM products;

-- C23. Total products and premium products count per category
SELECT 
    category,
    COUNT(*) AS total_products,
    SUM(CASE WHEN price >= 10000 THEN 1 ELSE 0 END) AS premium_products
FROM products
GROUP BY category;

-- C24. Comprehensive category breakdown (Categories with >= 3 products)
SELECT 
    category,
    COUNT(*) AS total_products,
    SUM(CASE WHEN is_active = TRUE THEN 1 ELSE 0 END) AS active_products,
    AVG(price) AS avg_price,
    CASE 
        WHEN AVG(price) < 1500 THEN 'Cheap'
        WHEN AVG(price) < 10000 THEN 'Standard'
        ELSE 'Luxury'
    END AS category_tier
FROM products
GROUP BY category
HAVING COUNT(*) >= 3
ORDER BY avg_price DESC;